using UnityEngine;

public class Bonus : MonoBehaviour
{
    public SquareColor color = SquareColor.Blue;
  
}
