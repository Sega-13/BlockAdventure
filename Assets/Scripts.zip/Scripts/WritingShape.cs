using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WritingShape : MonoBehaviour
{
    public void DeActivateWrite()
    {
        gameObject.SetActive(false);
    }
  
}
