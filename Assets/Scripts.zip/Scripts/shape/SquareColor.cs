public enum SquareColor
{
    Notset,
    Red,
    Blue,
    Orange,
    Mint,
    Yellow,
    Green,
    Pink,
    Purpule
}
