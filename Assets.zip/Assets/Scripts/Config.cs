using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Config : MonoBehaviour
{
   public enum SquareColor
    {
        Notset,
        Red,
        Blue,
        Orange,
        Mint,
        Yellow,
        Green,
        Pink,
        Purpule
    }
}
