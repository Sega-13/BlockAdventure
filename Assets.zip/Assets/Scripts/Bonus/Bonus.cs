using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bonus : MonoBehaviour
{
    public Config.SquareColor color = Config.SquareColor.Blue;
  
}
